package hbaseAgoraVai;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.security.auth.Subject;
import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginContext;
 
public class GetSubject {
	public static String principal = "hbase/spbrhdpdev1.br.experian.local@BR.EXPERIAN.LOCAL";
	private static String KeyTab = "C:/Users/spp5450/krb5.keytab";

	static Subject getSubject() throws Exception {
		System.setProperty("sun.security.krb5.debug", "true");
		System.setProperty("java.security.krb5.realm", "BR.EXPERIAN.LOCAL");
        System.setProperty("java.security.krb5.kdc","spobrdc3.br.experian.local");
        
        System.setProperty("java.security.krb5.conf", "C:/Users/spp5450/eclipse-workspace/hbaseAgoraVai/src/main/resources/krb5.conf");

		LoginContext context = new LoginContext("", new Subject(), null, new Configuration() {
			@Override
			public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
				Map<String, String> options = new HashMap<String, String>();
				options.put("useKeyTab", "true");
				options.put("KeyTab", new File(KeyTab).getAbsolutePath().toString());
				options.put("principal", principal);
				options.put("storeKey", "true");
				options.put("doNotPrompt", "true");
				options.put("useTicketCache", "true");
				options.put("renewTGT", "true");
				options.put("refreshKrb5Config", "true");
				options.put("isInitiator", "true");
				String ticketCache = System.getenv("KRB5CCNAME");
				if (ticketCache != null) {
					options.put("ticketCache", ticketCache);
				}
				options.put("debug", "true");

				return new AppConfigurationEntry[] {
						new AppConfigurationEntry("com.sun.security.auth.module.Krb5LoginModule",
								AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, options) };
			}
		});
		context.login();
		return context.getSubject();
	}
}
