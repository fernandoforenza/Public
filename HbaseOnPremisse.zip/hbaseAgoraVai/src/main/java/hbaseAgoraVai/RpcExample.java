package hbaseAgoraVai;

import java.security.PrivilegedExceptionAction;
import javax.security.auth.Subject;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.security.UserGroupInformation;


import java.util.logging.Logger;

public class RpcExample {

    private static String principal = "hbase/spbrhdpdev1.br.experian.local@BR.EXPERIAN.LOCAL";
    private static String KeyTab = "C:/Users/spp5450/krb5.keytab";

    public static void main(String[] args) throws Exception {

        Subject.doAs(GetSubject.getSubject(), new PrivilegedExceptionAction<Void>() {
            public Void run() throws Exception {

                Configuration conf = HBaseConfiguration.create();

                conf.set("hbase.zookeeper.quorum", "spbrhdpdev1.br.experian.local");
                conf.set("hbase.zookeeper.port", "2181");
                conf.set("hbase.rpc.protection", "authentication");
                conf.set("hadoop.security.authentication", "kerberos");
                conf.set("hbase.security.authentication", "kerberos");
                conf.set("hbase.client.retries.number", "1");
                conf.set("hbase.rpc.timeout", "1000");
                conf.set("hbase.regionserver.kerberos.principal","hbase/_HOST@BR.EXPERIAN.LOCAL");



                UserGroupInformation.setConfiguration(conf);
                UserGroupInformation.loginUserFromKeytab(principal, KeyTab);

				/*HTableDescriptor tableDescriptor = new
						HTableDescriptor(TableName.valueOf("freereport:teste"));
				tableDescriptor.addFamily(new HColumnDescriptor("personal"));
				tableDescriptor.addFamily(new HColumnDescriptor("employer"));
				tableDescriptor.addFamily(new HColumnDescriptor("contactinfo"));
				admin.createTable(tableDescriptor);
				System.out.println(" Table created ");
*/
                Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("freereport:score"));

                /*Get get = new Get(Bytes.toBytes("000052765"));
                get.addColumn(Bytes.toBytes("cf"), Bytes.toBytes("autoriza_pos"));
                Result result1 = table.get(get);
                System.out.println(result1);*/


                Scan scan1 = new Scan();
                ResultScanner scanner1 = table.getScanner(scan1);

                for (Result res : scanner1) {
                    System.out.println(res);
                }
                table.close();
                connection.close();
                return null;
            }
        });
    }
}