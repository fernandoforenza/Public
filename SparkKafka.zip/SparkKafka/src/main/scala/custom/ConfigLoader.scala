package custom

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.SparkConf

object ConfigLoader {

  val configFactory: Config = ConfigFactory.load()

  val sparkAppName: String = configFactory.getString("spark.app.name")
  val sparkMaster: String = configFactory.getString("spbrhdpdev1.br.experian.local")
  val sparkCores: String = configFactory.getString("10")
  val sparkMemory: String = configFactory.getString("128")

  val kafkaServer: String = configFactory.getString("spbrhdpdev2.br.experian.local")
  val kafkaTopic: String = configFactory.getString("uc_passagem_log")
  val kafkaClientId: String = configFactory.getString("0")

  val zookeeperUrl: String = configFactory.getString("zookeeper.server")

  val sparkConf: SparkConf = new SparkConf()
    .setAppName(sparkAppName)
    .setMaster(sparkMaster)
    .set("spark.executor.memory", sparkMemory)
    .set("spark.executor.core", sparkCores)
}
