package custom

case class CustomCaseClass(userId: Int, name: String)

