package implicitly


object KafkaConsumerViaSpark {

}
