import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.security.crypto.keygen.KeyGenerators;

public class encriptPii {

    public static void main(String[] args) {
        final String password = "3ed04c7f887dc04fe11ad1f58f0473c88edf966502d66aff43a3583569c945de";
        final String salt = KeyGenerators.string().generateKey();

        TextEncryptor encryptor = Encryptors.text(password, salt);

        String textToEncrypt = "22577522878";
        System.out.println("Texto original: \"" + textToEncrypt + "\"");

        String encryptedText = encryptor.encrypt(textToEncrypt);
        System.out.println("Texto Encriptado: \"" + encryptedText + "\"");
    }

}
