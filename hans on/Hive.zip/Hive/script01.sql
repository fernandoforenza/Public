create table estudantes
(ID INT,
nome VARCHAR(50),
sobrenome VARCHAR(50),
sexo Char(1),
email VARCHAR(100));


INSERT INTO estudantes
VALUES
(1000,'Barack','Obama','M','barack@gmail.com');
